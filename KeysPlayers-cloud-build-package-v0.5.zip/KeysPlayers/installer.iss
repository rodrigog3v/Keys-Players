#define MyAppName "Keys Players"
#define MyAppVersion "0.4.0-prototype"
#define MyAppPublisher "Personal Audio Tools"

[Setup]
AppId={{A64E8C43-4DA9-4F2C-9B2A-93A3AB8D50B1}
AppName={#MyAppName}
AppVersion={#MyAppVersion}
AppPublisher={#MyAppPublisher}
DefaultDirName={autopf}\Keys Players
DefaultGroupName=Keys Players
OutputDir=Output
OutputBaseFilename=KeysPlayers-Setup
ArchitecturesInstallIn64BitMode=x64
ArchitecturesAllowed=x64
Compression=lzma2
SolidCompression=yes
WizardStyle=modern
PrivilegesRequired=admin
UninstallDisplayIcon={app}\Keys Players.exe

[Tasks]
Name: "desktopicon"; Description: "Criar atalho na área de trabalho"; GroupDescription: "Atalhos:"; Flags: unchecked
Name: "vst3"; Description: "Instalar o plugin VST3 para o Ableton Live"; GroupDescription: "Componentes:"; Flags: checkedonce

[Files]
Source: "installer-stage\App\*"; DestDir: "{app}"; Flags: ignoreversion recursesubdirs createallsubdirs
Source: "installer-stage\VST3\Keys Players.vst3\*"; DestDir: "{commoncf}\VST3\Keys Players.vst3"; Flags: ignoreversion recursesubdirs createallsubdirs; Tasks: vst3

[Icons]
Name: "{autoprograms}\Keys Players"; Filename: "{app}\Keys Players.exe"
Name: "{autodesktop}\Keys Players"; Filename: "{app}\Keys Players.exe"; Tasks: desktopicon

[Run]
Filename: "{app}\Keys Players.exe"; Description: "Abrir Keys Players"; Flags: postinstall nowait skipifsilent
