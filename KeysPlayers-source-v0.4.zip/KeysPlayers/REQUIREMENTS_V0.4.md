# Keys Players — especificação funcional v0.4

Este documento converte as telas de referência em requisitos de implementação. Ele não afirma que todos os recursos abaixo já estejam implementados.

## A. Tela principal
- Identidade visual vermelha/preta, painel superior de programa e medidor de áudio.
- Seis canais de instrumento, cada um com selecionar arquivo, Editar, Reset, Mute, Solo, volume e medidor.
- Master volume e medidor de saída.
- Oito Drum Pads configuráveis.
- Ações de programa: Novo, Importar, Salvar, Excluir, Exportar e Live Set.
- Ações de teclado: mostrar/ocultar teclado virtual, painel Audio/MIDI, Panic e gravação WAV+MIDI.

## B. Editor de camada
- Tipo de fonte: SF2 ou Nord NPno (somente ativar Nord após implementação/validação do decoder).
- Seleção de arquivo, nome do preset e categoria.
- Ativação, volume, pan, mute, solo e reset por camada.
- Canal MIDI, entrada MIDI, sustain e transposição em oitavas/semitons.
- Limites de nota grave/aguda e split/zone.
- Curva de velocity e faixa de velocity.
- Controles de timbre Soft/Mid/Bright, ataque, release, cutoff e reverb.
- Controles de parâmetro com MIDI Learn, atribuição CC e indicação do CC atribuído.

## C. Performance MIDI
- MIDI USB e interfaces DIN-USB; no VST3, receber eventos MIDI do host.
- Nota ligada/desligada, velocity, sustain CC64, pitch bend, aftertouch e program change.
- Filtros por canal MIDI e por zona de teclado.
- MIDI Learn para volume, cutoff, reverb, compressor, mute, pads e master.
- Botão Panic que envia all-notes-off/all-sounds-off e limpa notas pendentes.

## D. Pads
- Oito pads, cada um com nota MIDI ou sample atribuído, canal, velocity e comportamento momentâneo/latch.
- LEDs/estado visual ao receber MIDI; mapeamento de notas configurável.
- Para primeira etapa, pads disparam notas MIDI. Reprodução de samples independentes é etapa posterior.

## E. Presets e Live Sets
- Preset de camada armazena fonte, preset SF2, nível, pan, zona, canal MIDI, curva de velocity e parâmetros.
- Live Set armazena até seis layers, pads, master e mapeamentos MIDI.
- Formato de projeto versionado (JSON ou XML), caminhos de mídia portáveis quando possível.
- Nunca sobrescrever arquivos SF2/NPno de origem; apenas guardar referências e parâmetros do projeto.

## F. Áudio e efeitos
- Renderização de camadas somadas com ganho e headroom; evitar clipping.
- Reverb, chorus, compressor e EQ por camada ou master, conforme orçamento de CPU.
- Driver ASIO no Standalone quando disponível; WASAPI como alternativa.
- No VST3, áudio/driver é controlado pelo host (ex.: Ableton Live).
- Gravação WAV estéreo e captura MIDI para arquivos separados.

## G. Formatos
- SF2: carregar preset e reproduzir por motor SoundFont, testar note-on/off, sustain e velocity.
- NPno: primeiro analisar estrutura, extrair dados sem perdas e identificar zonas, loops, velocity layers e metadados; implementar decoder só com entendimento do formato e testes comparativos. O protótipo atual apenas inspeciona o cabeçalho e NÃO reproduz NPno.
- DX7/Hammond/Minimoog: aparecem na referência, mas exigem engines/importadores específicos; não serão anunciados como suportados até existir implementação testada.

## H. Critérios de aceite
1. Build Release x64 para VST3 e Standalone.
2. SF2 reproduz notas, velocity, note-off e sustain sem travamentos.
3. Seis layers reproduzem simultaneamente com volume, mute, solo e zonas independentes.
4. MIDI Learn mapeia CC e pode ser salvo/carregado.
5. Live Set restaura todas as configurações após fechar e reabrir.
6. Gravações WAV/MIDI podem ser abertas em ferramentas externas.
7. NPno só passa a ser marcado como suportado após testes com múltiplos arquivos e comparação das amostras/loops extraídos.

## Ordem de implementação
1. SF2 engine estável e testes básicos.
2. Seis engines/layers com zona, volume, mute/solo.
3. Persistência de presets e Live Sets.
4. Entrada MIDI Standalone, MIDI Learn e pads.
5. Efeitos e gravação.
6. Decoder NPno, reprodução por regiões/loops/velocity e testes de fidelidade.
7. Empacotamento/instalador Windows.
