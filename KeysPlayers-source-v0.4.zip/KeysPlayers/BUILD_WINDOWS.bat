@echo off
setlocal
if "%VCPKG_ROOT%"=="" set VCPKG_ROOT=C:\dev\vcpkg
cmake -S . -B build -A x64 -DCMAKE_TOOLCHAIN_FILE=%VCPKG_ROOT%/scripts/buildsystems/vcpkg.cmake
if errorlevel 1 goto fail
cmake --build build --config Release --target KeysPlayers_VST3 KeysPlayers_Standalone
if errorlevel 1 goto fail
echo Build concluido. Veja a pasta build\KeysPlayers_artefacts\Release.
goto end
:fail
echo Falha na compilacao. Consulte a mensagem de erro acima e o README.md.
exit /b 1
:end
endlocal
