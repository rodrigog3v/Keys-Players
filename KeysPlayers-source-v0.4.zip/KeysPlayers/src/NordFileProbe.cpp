#include "NordFileProbe.h"

NordProbeResult inspectNordPianoFile(const juce::File& file)
{
    NordProbeResult r;
    if (!file.existsAsFile()) { r.message = "Arquivo não encontrado."; return r; }
    juce::FileInputStream stream(file);
    if (!stream.openedOk()) { r.message = "Não foi possível ler o arquivo."; return r; }
    char header[4] = {};
    if (stream.read(header, 4) != 4) { r.message = "Arquivo muito pequeno para identificar."; return r; }
    r.signature = juce::String::fromUTF8(header, 4);
    r.recognised = (r.signature == "CBIN") && file.getFileExtension().compareIgnoreCase(".npno") == 0;
    if (r.recognised)
        r.message = "Cabeçalho CBIN reconhecido. Esta versão ainda não extrai nem reproduz as amostras NPno; somente identificou o formato.";
    else
        r.message = "O arquivo não corresponde à assinatura esperada CBIN + extensão .npno.";
    return r;
}
