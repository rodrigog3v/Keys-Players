#include "Sf2Engine.h"

Sf2Engine::Sf2Engine() = default;
Sf2Engine::~Sf2Engine() { destroy(); }

void Sf2Engine::destroy()
{
    if (synth != nullptr) { delete_fluid_synth(synth); synth = nullptr; }
    if (settings != nullptr) { delete_fluid_settings(settings); settings = nullptr; }
    soundFontId = -1;
    currentFileName.clear();
}

void Sf2Engine::prepare(double sampleRate, int maxBlockSize)
{
    currentSampleRate = sampleRate > 0.0 ? sampleRate : 44100.0;
    currentMaxBlockSize = juce::jmax(64, maxBlockSize);
    // FluidSynth's sample rate is fixed at creation. If already loaded, reload the same
    // SF2 at the new rate. The full path is retained by the processor state.
    if (synth != nullptr)
    {
        const auto oldName = currentFileName;
        destroy();
        juce::ignoreUnused(oldName);
    }
}

bool Sf2Engine::loadSoundFont(const juce::File& file, juce::String& error)
{
    if (!file.existsAsFile()) { error = "Arquivo não encontrado."; return false; }
    if (file.getFileExtension().compareIgnoreCase(".sf2") != 0)
    { error = "Nesta versão, o leitor de áudio aceita SF2. NPno ainda está em análise."; return false; }

    // Create a fresh synth so a failed load does not leave a half-loaded bank active.
    fluid_settings_t* newSettings = new_fluid_settings();
    if (newSettings == nullptr) { error = "Não foi possível criar as configurações do FluidSynth."; return false; }
    fluid_settings_setnum(newSettings, "synth.sample-rate", currentSampleRate);
    fluid_settings_setnum(newSettings, "synth.gain", 0.7);
    fluid_settings_setint(newSettings, "synth.polyphony", 256);
    fluid_settings_setint(newSettings, "synth.reverb.active", 0);
    fluid_settings_setint(newSettings, "synth.chorus.active", 0);
    fluid_synth_t* newSynth = new_fluid_synth(newSettings);
    if (newSynth == nullptr)
    { delete_fluid_settings(newSettings); error = "Não foi possível iniciar o motor de áudio SF2."; return false; }

    const auto path = file.getFullPathName().toStdString();
    const int newId = fluid_synth_sfload(newSynth, path.c_str(), 1);
    if (newId < 0)
    {
        delete_fluid_synth(newSynth); delete_fluid_settings(newSettings);
        error = "FluidSynth não conseguiu abrir este SF2. Verifique se o arquivo está íntegro.";
        return false;
    }

    destroy();
    settings = newSettings;
    synth = newSynth;
    soundFontId = newId;
    currentFileName = file.getFileName();
    error.clear();
    return true;
}

void Sf2Engine::handleMidi(const juce::MidiMessage& m)
{
    if (synth == nullptr) return;
    if (m.isNoteOn()) fluid_synth_noteon(synth, m.getChannel(), m.getNoteNumber(), m.getVelocity());
    else if (m.isNoteOff()) fluid_synth_noteoff(synth, m.getChannel(), m.getNoteNumber());
    else if (m.isAllNotesOff() || m.isAllSoundOff()) fluid_synth_all_sounds_off(synth, m.getChannel());
    else if (m.isController()) fluid_synth_cc(synth, m.getChannel(), m.getControllerNumber(), m.getControllerValue());
    else if (m.isPitchWheel()) fluid_synth_pitch_wheel(synth, m.getChannel(), m.getPitchWheelValue());
    else if (m.isProgramChange()) fluid_synth_program_change(synth, m.getChannel(), m.getProgramChangeNumber());
    else if (m.isChannelPressure()) fluid_synth_channel_pressure(synth, m.getChannel(), m.getChannelPressureValue());
    else if (m.isAftertouch()) fluid_synth_key_pressure(synth, m.getChannel(), m.getNoteNumber(), m.getAfterTouchValue());
}

void Sf2Engine::render(float* left, float* right, int numSamples)
{
    if (numSamples <= 0) return;
    if (synth == nullptr)
    {
        juce::FloatVectorOperations::clear(left, numSamples);
        juce::FloatVectorOperations::clear(right, numSamples);
        return;
    }
    fluid_synth_write_float(synth, numSamples, left, 0, 1, right, 0, 1);
}
