#include "PluginProcessor.h"
#include "PluginEditor.h"

KeysPlayersAudioProcessor::KeysPlayersAudioProcessor()
    : AudioProcessor(BusesProperties().withOutput("Output", juce::AudioChannelSet::stereo(), true)) {}

void KeysPlayersAudioProcessor::prepareToPlay(double sr, int samplesPerBlock)
{
    sampleRate = sr; blockSize = samplesPerBlock;
    // Recreate engine at the host's sample rate, then reload the current SF2 if any.
    engine.prepare(sampleRate, blockSize);
    if (lastLoadedPath.isNotEmpty())
    {
        juce::String ignored;
        engine.loadSoundFont(juce::File(lastLoadedPath), ignored);
    }
}

void KeysPlayersAudioProcessor::releaseResources() {}

bool KeysPlayersAudioProcessor::isBusesLayoutSupported(const BusesLayout& layouts) const
{
    return layouts.getMainOutputChannelSet() == juce::AudioChannelSet::stereo();
}

void KeysPlayersAudioProcessor::processBlock(juce::AudioBuffer<float>& buffer, juce::MidiBuffer& midi)
{
    juce::ScopedNoDenormals noDenormals;
    const juce::ScopedLock lock(stateLock);
    const int n = buffer.getNumSamples();
    auto* left = buffer.getWritePointer(0);
    auto* right = buffer.getNumChannels() > 1 ? buffer.getWritePointer(1) : left;
    int rendered = 0;
    for (const auto metadata : midi)
    {
        const int eventPos = juce::jlimit(rendered, n, metadata.samplePosition);
        if (eventPos > rendered)
        {
            engine.render(left + rendered, right + rendered, eventPos - rendered);
            rendered = eventPos;
        }
        engine.handleMidi(metadata.getMessage());
    }
    if (rendered < n) engine.render(left + rendered, right + rendered, n - rendered);
    if (buffer.getNumChannels() > 1 && left == right) buffer.copyFrom(1, 0, buffer, 0, 0, n);
}

juce::AudioProcessorEditor* KeysPlayersAudioProcessor::createEditor()
{ return new KeysPlayersAudioProcessorEditor(*this); }

bool KeysPlayersAudioProcessor::loadFile(const juce::File& file, juce::String& result)
{
    if (file.getFileExtension().compareIgnoreCase(".npno") == 0)
    {
        const auto probe = inspectNordPianoFile(file);
        result = probe.message;
        const juce::ScopedLock lock(stateLock); status = result;
        return false;
    }
    const juce::ScopedLock lock(stateLock);
    if (engine.loadSoundFont(file, result))
    {
        lastLoadedPath = file.getFullPathName();
        status = "SF2 carregado: " + file.getFileName();
        return true;
    }
    status = result;
    return false;
}

juce::String KeysPlayersAudioProcessor::getStatus() const
{ const juce::ScopedLock lock(stateLock); return status; }
juce::String KeysPlayersAudioProcessor::getLoadedFileName() const
{ const juce::ScopedLock lock(stateLock); return engine.loadedFileName(); }

void KeysPlayersAudioProcessor::getStateInformation(juce::MemoryBlock& destData)
{
    juce::XmlElement state("KeysPlayersState");
    state.setAttribute("lastLoadedPath", lastLoadedPath);
    copyXmlToBinary(state, destData);
}
void KeysPlayersAudioProcessor::setStateInformation(const void* data, int sizeInBytes)
{
    if (auto xml = getXmlFromBinary(data, sizeInBytes))
        if (xml->hasTagName("KeysPlayersState"))
        {
            lastLoadedPath = xml->getStringAttribute("lastLoadedPath");
            if (lastLoadedPath.isNotEmpty() && juce::File(lastLoadedPath).existsAsFile())
            { juce::String ignored; loadFile(juce::File(lastLoadedPath), ignored); }
        }
}

juce::AudioProcessor* JUCE_CALLTYPE createPluginFilter()
{ return new KeysPlayersAudioProcessor(); }
