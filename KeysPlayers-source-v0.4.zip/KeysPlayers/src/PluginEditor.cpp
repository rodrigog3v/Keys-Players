#include "PluginEditor.h"

namespace
{
    const juce::Colour bg { 20, 21, 25 }, panel { 48, 24, 31 }, red { 196, 29, 48 }, text { 245, 241, 242 };
    const juce::Colour layerColours[] = { juce::Colour(116,32,47), juce::Colour(20,74,111), juce::Colour(77,43,111), juce::Colour(86,79,65), juce::Colour(105,43,35), juce::Colour(36,83,72) };
}

KeysPlayersAudioProcessorEditor::KeysPlayersAudioProcessorEditor(KeysPlayersAudioProcessor& p)
    : AudioProcessorEditor(&p), processor(p)
{
    setSize(1080, 720);
    setResizable(true, true);
    setResizeLimits(850, 600, 1600, 1100);

    brand.setText("KEYS PLAYERS", juce::dontSendNotification);
    brand.setFont(juce::FontOptions(29.0f, juce::Font::bold));
    brand.setColour(juce::Label::textColourId, text);
    addAndMakeVisible(brand);
    subtitle.setText("SF2  •  NORD NPNO  •  MIDI WORKSTATION", juce::dontSendNotification);
    subtitle.setFont(juce::FontOptions(12.0f, juce::Font::bold));
    subtitle.setColour(juce::Label::textColourId, juce::Colour(255, 70, 88));
    addAndMakeVisible(subtitle);

    for (auto* b : { &importButton, &saveButton, &exportButton, &newSetButton, &midiLearnButton, &showKeyboardButton, &recordButton, &npnoButton })
    { addAndMakeVisible(b); styleButton(*b, red); }
    styleButton(saveButton, juce::Colour(112, 31, 43));
    styleButton(exportButton, juce::Colour(112, 31, 43));
    styleButton(newSetButton, juce::Colour(112, 31, 43));

    status.setText(processor.getStatus(), juce::dontSendNotification);
    status.setColour(juce::Label::textColourId, juce::Colour(255, 214, 219));
    status.setFont(juce::FontOptions(13.0f));
    status.setJustificationType(juce::Justification::centredLeft);
    addAndMakeVisible(status);
    midiStatus.setText("MIDI: entrada pelo host VST3 ou dispositivo Standalone  |  ASIO configurado no host", juce::dontSendNotification);
    midiStatus.setColour(juce::Label::textColourId, juce::Colours::silver);
    midiStatus.setFont(juce::FontOptions(12.0f));
    addAndMakeVisible(midiStatus);

    for (int i = 0; i < 6; ++i)
    {
        auto* select = layerSelectButtons.add(new juce::TextButton("LAYER " + juce::String(i + 1)));
        styleButton(*select, layerColours[i]); addAndMakeVisible(select);
        select->onClick = [this, i] { activeLayer = i; refreshStatus(); repaint(); };
        auto* mute = muteButtons.add(new juce::TextButton("M"));
        auto* solo = soloButtons.add(new juce::TextButton("S"));
        styleButton(*mute, juce::Colour(38,38,42)); styleButton(*solo, juce::Colour(38,38,42));
        addAndMakeVisible(mute); addAndMakeVisible(solo);
        mute->setTooltip("Mute da camada — o mixer multi-camada será ligado na próxima etapa");
        solo->setTooltip("Solo da camada — o mixer multi-camada será ligado na próxima etapa");
        auto* vol = layerVolumes.add(new juce::Slider());
        vol->setSliderStyle(juce::Slider::LinearVertical); vol->setTextBoxStyle(juce::Slider::TextBoxBelow, false, 48, 20);
        vol->setRange(0.0, 1.0, 0.01); vol->setValue(i == 0 ? 0.76 : 0.70); vol->setTextValueSuffix(" ");
        vol->setColour(juce::Slider::trackColourId, juce::Colour(240, 220, 223)); vol->setColour(juce::Slider::thumbColourId, juce::Colours::white);
        addAndMakeVisible(vol);
        auto* name = layerTitles.add(new juce::Label()); name->setText("LAYER " + juce::String(i + 1), juce::dontSendNotification); name->setFont(juce::FontOptions(13.0f, juce::Font::bold)); name->setColour(juce::Label::textColourId, text); addAndMakeVisible(name);
        auto* file = layerFiles.add(new juce::Label()); file->setText(i == 0 ? "SF2 / NORD" : "Vazio"); file->setFont(juce::FontOptions(11.0f)); file->setColour(juce::Label::textColourId, juce::Colour(240,220,223)); file->setJustificationType(juce::Justification::centred); addAndMakeVisible(file);
        auto* cc = layerCcLabels.add(new juce::Label()); cc->setText("CC " + juce::String(71 + i) + "  CH 1", juce::dontSendNotification); cc->setFont(juce::FontOptions(10.0f)); cc->setColour(juce::Label::textColourId, juce::Colours::white); addAndMakeVisible(cc);
    }

    for (int i = 0; i < 8; ++i)
    {
        auto* pad = padButtons.add(new juce::TextButton("PAD " + juce::String(i + 1)));
        const juce::Colour colours[] = { juce::Colour(36,139,204), juce::Colour(155,67,191), juce::Colour(221,91,119), juce::Colour(226,151,54), juce::Colour(46,164,133), juce::Colour(216,191,57), juce::Colour(48,169,187), juce::Colour(190,73,133) };
        styleButton(*pad, colours[i]); addAndMakeVisible(pad);
        pad->setTooltip("Interface visual; atribuição e disparo MIDI serão implementados no módulo de pads");
    }
    masterLabel.setText("MASTER", juce::dontSendNotification); masterLabel.setFont(juce::FontOptions(13.0f, juce::Font::bold)); masterLabel.setColour(juce::Label::textColourId, text); masterLabel.setJustificationType(juce::Justification::centred); addAndMakeVisible(masterLabel);
    masterVolume.setSliderStyle(juce::Slider::LinearVertical); masterVolume.setTextBoxStyle(juce::Slider::TextBoxBelow, false, 48, 20); masterVolume.setRange(0.0, 1.0, 0.01); masterVolume.setValue(0.8); addAndMakeVisible(masterVolume);

    importButton.onClick = [this] { chooseFileForActiveLayer(); };
    npnoButton.onClick = [this]
    {
        chooser = std::make_unique<juce::FileChooser>("Selecione um piano Nord .npno para análise", juce::File{}, "*.npno");
        chooser->launchAsync(juce::FileBrowserComponent::openMode | juce::FileBrowserComponent::canSelectFiles, [this](const juce::FileChooser& fc)
        { const auto f = fc.getResult(); if (f.existsAsFile()) { juce::String result; processor.loadFile(f, result); status.setText(result, juce::dontSendNotification); } });
    };
    newSetButton.onClick = [this] { status.setText("Novo Live Set: estrutura visual pronta; persistência de camadas será implementada em seguida.", juce::dontSendNotification); };
    saveButton.onClick = [this] { status.setText("Salvar Live Set: função de arquivo ainda não conectada nesta versão.", juce::dontSendNotification); };
    exportButton.onClick = [this] { status.setText("Exportar: função de exportação ainda não conectada nesta versão.", juce::dontSendNotification); };
    midiLearnButton.onClick = [this] { status.setText("MIDI Learn: mapeamento CC ainda não conectado nesta versão.", juce::dontSendNotification); };
    showKeyboardButton.onClick = [this] { keyboardVisible = !keyboardVisible; status.setText(keyboardVisible ? "Teclado virtual selecionado (interação será implementada)." : "Teclado virtual oculto.", juce::dontSendNotification); resized(); };
    recordButton.onClick = [this] { status.setText("Gravação WAV + MIDI ainda não conectada nesta versão.", juce::dontSendNotification); };
}

void KeysPlayersAudioProcessorEditor::styleButton(juce::TextButton& b, juce::Colour c)
{
    b.setColour(juce::TextButton::buttonColourId, c);
    b.setColour(juce::TextButton::buttonOnColourId, c.brighter(0.2f));
    b.setColour(juce::TextButton::textColourOffId, juce::Colours::white);
    b.setColour(juce::TextButton::textColourOnId, juce::Colours::white);
    b.setConnectedEdges(juce::Button::ConnectedOnLeft | juce::Button::ConnectedOnRight | juce::Button::ConnectedOnTop | juce::Button::ConnectedOnBottom);
}

void KeysPlayersAudioProcessorEditor::chooseFileForActiveLayer()
{
    chooser = std::make_unique<juce::FileChooser>("Selecione um arquivo SF2", juce::File{}, "*.sf2");
    chooser->launchAsync(juce::FileBrowserComponent::openMode | juce::FileBrowserComponent::canSelectFiles, [this](const juce::FileChooser& fc)
    {
        const auto f = fc.getResult();
        if (f.existsAsFile())
        {
            juce::String message;
            if (processor.loadFile(f, message))
                layerFiles[activeLayer]->setText(f.getFileName(), juce::dontSendNotification);
            status.setText("Camada " + juce::String(activeLayer + 1) + ": " + message + " (motor de áudio atual: uma camada SF2 ativa).", juce::dontSendNotification);
        }
    });
}

void KeysPlayersAudioProcessorEditor::refreshStatus()
{
    status.setText("Camada selecionada: " + juce::String(activeLayer + 1) + ". " + processor.getStatus(), juce::dontSendNotification);
}

void KeysPlayersAudioProcessorEditor::paint(juce::Graphics& g)
{
    g.fillAll(bg);
    g.setColour(red); g.fillRoundedRectangle(15.0f, 15.0f, 5.0f, 52.0f, 2.0f);
    g.setColour(juce::Colour(75, 75, 82)); g.drawRoundedRectangle(getLocalBounds().toFloat().reduced(1.0f), 8.0f, 1.0f);
    auto bounds = getLocalBounds().toFloat();
    g.setColour(juce::Colour(37, 24, 29)); g.fillRoundedRectangle(bounds.removeFromTop(112.0f).reduced(8.0f), 8.0f);
    auto area = getLocalBounds().reduced(14);
    area.removeFromTop(130);
    auto layers = area.removeFromTop((getHeight() - 240) * (keyboardVisible ? 0.55f : 0.66f));
    const int gap = 7, cardW = (layers.getWidth() - gap * 5) / 6;
    for (int i = 0; i < 6; ++i)
    {
        auto r = juce::Rectangle<int>(layers.getX() + i * (cardW + gap), layers.getY(), cardW, layers.getHeight());
        g.setColour(layerColours[i].withAlpha(i == activeLayer ? 1.0f : 0.78f)); g.fillRoundedRectangle(r.toFloat(), 6.0f);
        if (i == activeLayer) { g.setColour(juce::Colours::white); g.drawRoundedRectangle(r.toFloat().reduced(1.0f), 6.0f, 2.0f); }
    }
    auto padArea = getLocalBounds().reduced(14).withTrimmedTop(130).withTrimmedBottom(90);
    const int padX = padArea.getX() + padArea.getWidth() * 2 / 3;
    g.setColour(panel); g.fillRoundedRectangle(juce::Rectangle<float>((float)padX, (float)padArea.getY(), (float)(padArea.getRight()-padX), (float)padArea.getHeight()).reduced(2.0f), 6.0f);
    g.setColour(juce::Colour(255, 60, 80)); g.setFont(juce::FontOptions(12.0f, juce::Font::bold)); g.drawText("DRUM PADS", padX + 8, padArea.getY() + 6, padArea.getWidth() / 3 - 12, 20, juce::Justification::centredLeft);
}

void KeysPlayersAudioProcessorEditor::resized()
{
    auto area = getLocalBounds().reduced(20);
    auto header = area.removeFromTop(65);
    brand.setBounds(header.removeFromTop(36)); subtitle.setBounds(header);
    area.removeFromTop(4);
    auto actions = area.removeFromTop(34);
    importButton.setBounds(actions.removeFromLeft(130)); actions.removeFromLeft(5);
    npnoButton.setBounds(actions.removeFromLeft(170)); actions.removeFromLeft(5);
    newSetButton.setBounds(actions.removeFromLeft(125)); actions.removeFromLeft(5);
    saveButton.setBounds(actions.removeFromLeft(95)); actions.removeFromLeft(5);
    exportButton.setBounds(actions.removeFromLeft(90)); actions.removeFromLeft(5);
    midiLearnButton.setBounds(actions.removeFromLeft(100));
    area.removeFromTop(5);
    auto controls = area.removeFromTop(28);
    recordButton.setBounds(controls.removeFromLeft(150)); controls.removeFromLeft(6); showKeyboardButton.setBounds(controls.removeFromLeft(155));
    status.setBounds(controls.reduced(2));
    area.removeFromTop(6);
    auto main = area.removeFromTop((keyboardVisible ? area.getHeight() * 0.56 : area.getHeight() * 0.70));
    auto layerArea = main.removeFromLeft(main.getWidth() * 0.70);
    const int gap = 7, w = (layerArea.getWidth() - gap * 5) / 6;
    for (int i = 0; i < 6; ++i)
    {
        auto card = juce::Rectangle<int>(layerArea.getX() + i * (w + gap), layerArea.getY(), w, layerArea.getHeight());
        layerSelectButtons[i]->setBounds(card.removeFromTop(30));
        auto ms = card.removeFromTop(24); muteButtons[i]->setBounds(ms.removeFromLeft(ms.getWidth()/2).reduced(2)); soloButtons[i]->setBounds(ms.reduced(2));
        layerTitles[i]->setBounds(card.removeFromTop(22)); layerFiles[i]->setBounds(card.removeFromTop(42));
        auto sliderArea = card.reduced(2); sliderArea.removeFromTop(2); layerVolumes[i]->setBounds(sliderArea.removeFromTop(juce::jmax(90, sliderArea.getHeight()-22)));
        layerCcLabels[i]->setBounds(card.removeFromBottom(18));
    }
    auto right = main;
    masterLabel.setBounds(right.removeFromTop(28)); masterVolume.setBounds(right.removeFromRight(62).reduced(2));
    right.removeFromTop(2);
    auto padGrid = right.reduced(3); const int pg = 5, pw = (padGrid.getWidth()-pg)/2, ph = (padGrid.getHeight()-pg*3)/4;
    for (int i=0;i<8;++i) { const int col=i%2, row=i/2; padButtons[i]->setBounds(padGrid.getX()+col*(pw+pg), padGrid.getY()+row*(ph+pg), pw, ph); }
    if (keyboardVisible)
    {
        auto keyboard = area.removeFromTop(68);
        // Placeholder keyboard area reserved for the upcoming interactive MIDI keyboard.
        midiStatus.setBounds(keyboard);
    }
    else midiStatus.setBounds(area.removeFromTop(26));
}
