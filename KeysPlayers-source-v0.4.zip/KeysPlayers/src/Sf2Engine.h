#pragma once
#include <juce_core/juce_core.h>
#include <fluidsynth.h>
#include <memory>

class Sf2Engine
{
public:
    Sf2Engine();
    ~Sf2Engine();
    Sf2Engine(const Sf2Engine&) = delete;
    Sf2Engine& operator=(const Sf2Engine&) = delete;

    void prepare(double sampleRate, int maxBlockSize);
    bool loadSoundFont(const juce::File& file, juce::String& error);
    void render(float* left, float* right, int numSamples);
    void handleMidi(const juce::MidiMessage& message);
    bool isLoaded() const noexcept { return soundFontId >= 0; }
    juce::String loadedFileName() const { return currentFileName; }

private:
    void destroy();
    fluid_settings_t* settings = nullptr;
    fluid_synth_t* synth = nullptr;
    int soundFontId = -1;
    double currentSampleRate = 44100.0;
    int currentMaxBlockSize = 512;
    juce::String currentFileName;
};
