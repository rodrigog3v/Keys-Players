#pragma once
#include <juce_audio_utils/juce_audio_utils.h>
#include "Sf2Engine.h"
#include "NordFileProbe.h"

class KeysPlayersAudioProcessor final : public juce::AudioProcessor
{
public:
    KeysPlayersAudioProcessor();
    ~KeysPlayersAudioProcessor() override = default;

    void prepareToPlay(double sampleRate, int samplesPerBlock) override;
    void releaseResources() override;
    bool isBusesLayoutSupported(const BusesLayout& layouts) const override;
    void processBlock(juce::AudioBuffer<float>&, juce::MidiBuffer&) override;
    juce::AudioProcessorEditor* createEditor() override;
    bool hasEditor() const override { return true; }
    const juce::String getName() const override { return JucePlugin_Name; }
    bool acceptsMidi() const override { return true; }
    bool producesMidi() const override { return false; }
    bool isMidiEffect() const override { return false; }
    double getTailLengthSeconds() const override { return 4.0; }
    int getNumPrograms() override { return 1; }
    int getCurrentProgram() override { return 0; }
    void setCurrentProgram(int) override {}
    const juce::String getProgramName(int) override { return "Default"; }
    void changeProgramName(int, const juce::String&) override {}
    void getStateInformation(juce::MemoryBlock&) override;
    void setStateInformation(const void*, int) override;

    bool loadFile(const juce::File& file, juce::String& result);
    juce::String getStatus() const;
    juce::String getLoadedFileName() const;

private:
    Sf2Engine engine;
    juce::String status = "Abra um arquivo SF2 para começar. NPno: leitor ainda não implementado.";
    juce::String lastLoadedPath;
    double sampleRate = 44100.0;
    int blockSize = 512;
    juce::CriticalSection stateLock;
    JUCE_DECLARE_NON_COPYABLE_WITH_LEAK_DETECTOR(KeysPlayersAudioProcessor)
};
