#pragma once
#include <juce_audio_utils/juce_audio_utils.h>
#include "PluginProcessor.h"

class KeysPlayersAudioProcessorEditor final : public juce::AudioProcessorEditor
{
public:
    explicit KeysPlayersAudioProcessorEditor(KeysPlayersAudioProcessor&);
    void paint(juce::Graphics&) override;
    void resized() override;
private:
    void chooseFileForActiveLayer();
    void refreshStatus();
    void styleButton(juce::TextButton&, juce::Colour colour);

    KeysPlayersAudioProcessor& processor;
    juce::Label brand, subtitle, status, midiStatus, masterLabel;
    juce::TextButton importButton { "IMPORTAR SOM" }, saveButton { "SALVAR SET" }, exportButton { "EXPORTAR" }, newSetButton { "NOVO LIVE SET" }, midiLearnButton { "MIDI LEARN" }, showKeyboardButton { "MOSTRAR TECLADO" }, recordButton { "GRAVAR WAV + MIDI" };
    juce::TextButton npnoButton { "INSPECIONAR NORD .NPNO" };
    juce::OwnedArray<juce::TextButton> layerSelectButtons, muteButtons, soloButtons;
    juce::OwnedArray<juce::Slider> layerVolumes;
    juce::OwnedArray<juce::Label> layerTitles, layerFiles, layerCcLabels;
    juce::OwnedArray<juce::TextButton> padButtons;
    juce::Slider masterVolume;
    std::unique_ptr<juce::FileChooser> chooser;
    int activeLayer = 0;
    bool keyboardVisible = false;
    JUCE_DECLARE_NON_COPYABLE_WITH_LEAK_DETECTOR(KeysPlayersAudioProcessorEditor)
};
