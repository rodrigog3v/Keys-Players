#pragma once
#include <juce_core/juce_core.h>

struct NordProbeResult
{
    bool recognised = false;
    juce::String signature;
    juce::String message;
};

// Safe first-stage probe only. This does NOT decode or render NPno audio.
NordProbeResult inspectNordPianoFile(const juce::File& file);
